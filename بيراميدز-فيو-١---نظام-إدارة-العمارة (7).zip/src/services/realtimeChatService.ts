import { 
  collection, 
  doc, 
  setDoc, 
  deleteDoc, 
  onSnapshot, 
  getDocs, 
  query, 
  orderBy 
} from 'firebase/firestore';
import { db } from './firebaseConfig';
import { ChatMessage, PublicComplaint, ComplaintComment } from '../types';

const CHAT_COLLECTION = 'chat_messages';
const COMPLAINTS_COLLECTION = 'public_complaints';
const BROADCAST_CHANNEL_NAME = 'pyramids_community_channel';

// Setup BroadcastChannel for local instant cross-tab sync
let channel: BroadcastChannel | null = null;
try {
  if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
    channel = new BroadcastChannel(BROADCAST_CHANNEL_NAME);
  }
} catch {
  channel = null;
}

/**
 * Realtime Chat listener
 */
export function subscribeToChatMessages(
  onUpdate: (messages: ChatMessage[]) => void
): () => void {
  let unsubFirestore: (() => void) | null = null;

  try {
    const q = query(collection(db, CHAT_COLLECTION));
    unsubFirestore = onSnapshot(
      q,
      (snapshot) => {
        const list: ChatMessage[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data() as ChatMessage;
          list.push({ ...data, id: docSnap.id || data.id });
        });
        // Sort by timestamp
        list.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
        if (list.length > 0) {
          onUpdate(list);
        }
      },
      (error) => {
        console.warn('Firestore chat listener notice:', error?.message || error);
      }
    );
  } catch (err) {
    console.warn('Could not initialize Firestore chat listener:', err);
  }

  // Also listen for BroadcastChannel updates from other tabs
  const handleBroadcast = (event: MessageEvent) => {
    if (event.data?.type === 'CHAT_UPDATED' && Array.isArray(event.data?.messages)) {
      onUpdate(event.data.messages);
    }
  };

  if (channel) {
    channel.addEventListener('message', handleBroadcast);
  }

  return () => {
    if (unsubFirestore) unsubFirestore();
    if (channel) channel.removeEventListener('message', handleBroadcast);
  };
}

/**
 * Send a new chat message
 */
export async function sendChatMessage(msg: ChatMessage, currentList: ChatMessage[]): Promise<void> {
  const updatedList = [...currentList, msg];

  // 1. Broadcast to local tabs
  if (channel) {
    try {
      channel.postMessage({ type: 'CHAT_UPDATED', messages: updatedList });
    } catch {}
  }

  // 2. Save to Express server endpoint if available
  try {
    fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: msg }),
    }).catch(() => {});
  } catch {}

  // 3. Save to Firestore for global real-time multi-device sync
  try {
    const docRef = doc(db, CHAT_COLLECTION, msg.id);
    await setDoc(docRef, msg, { merge: true });
  } catch (err) {
    console.warn('Firestore message save error:', err);
  }
}

/**
 * Edit a chat message
 */
export async function editChatMessage(msgId: string, newText: string, currentList: ChatMessage[]): Promise<void> {
  const updatedList = currentList.map(m => m.id === msgId ? { ...m, text: newText } : m);

  if (channel) {
    try {
      channel.postMessage({ type: 'CHAT_UPDATED', messages: updatedList });
    } catch {}
  }

  try {
    fetch('/api/chat/edit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messageId: msgId, newText }),
    }).catch(() => {});
  } catch {}

  try {
    const docRef = doc(db, CHAT_COLLECTION, msgId);
    await setDoc(docRef, { text: newText }, { merge: true });
  } catch (err) {
    console.warn('Firestore edit message error:', err);
  }
}

/**
 * Delete a chat message
 */
export async function deleteChatMessage(msgId: string, currentList: ChatMessage[]): Promise<void> {
  const updatedList = currentList.filter(m => m.id !== msgId);

  if (channel) {
    try {
      channel.postMessage({ type: 'CHAT_UPDATED', messages: updatedList });
    } catch {}
  }

  try {
    fetch(`/api/chat/${msgId}`, { method: 'DELETE' }).catch(() => {});
  } catch {}

  try {
    const docRef = doc(db, CHAT_COLLECTION, msgId);
    await deleteDoc(docRef);
  } catch (err) {
    console.warn('Firestore delete message error:', err);
  }
}

/**
 * Realtime Complaints listener
 */
export function subscribeToComplaints(
  onUpdate: (complaints: PublicComplaint[]) => void
): () => void {
  let unsubFirestore: (() => void) | null = null;

  try {
    const q = query(collection(db, COMPLAINTS_COLLECTION));
    unsubFirestore = onSnapshot(
      q,
      (snapshot) => {
        const list: PublicComplaint[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data() as PublicComplaint;
          list.push({ ...data, id: docSnap.id || data.id });
        });
        list.sort((a, b) => new Date(b.date || 0).getTime() - new Date(a.date || 0).getTime());
        if (list.length > 0) {
          onUpdate(list);
        }
      },
      (error) => {
        console.warn('Firestore complaints listener notice:', error?.message || error);
      }
    );
  } catch (err) {
    console.warn('Could not initialize Firestore complaints listener:', err);
  }

  const handleBroadcast = (event: MessageEvent) => {
    if (event.data?.type === 'COMPLAINTS_UPDATED' && Array.isArray(event.data?.complaints)) {
      onUpdate(event.data.complaints);
    }
  };

  if (channel) {
    channel.addEventListener('message', handleBroadcast);
  }

  return () => {
    if (unsubFirestore) unsubFirestore();
    if (channel) channel.removeEventListener('message', handleBroadcast);
  };
}

/**
 * Add a new Complaint
 */
export async function addComplaint(complaint: PublicComplaint, currentList: PublicComplaint[]): Promise<void> {
  const updatedList = [complaint, ...currentList];

  if (channel) {
    try {
      channel.postMessage({ type: 'COMPLAINTS_UPDATED', complaints: updatedList });
    } catch {}
  }

  try {
    fetch('/api/complaints', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ complaint }),
    }).catch(() => {});
  } catch {}

  try {
    const docRef = doc(db, COMPLAINTS_COLLECTION, complaint.id);
    await setDoc(docRef, complaint, { merge: true });
  } catch (err) {
    console.warn('Firestore complaint save error:', err);
  }
}

/**
 * Save updated complaint (e.g. comment added or edited)
 */
export async function saveUpdatedComplaint(complaint: PublicComplaint, currentList: PublicComplaint[]): Promise<void> {
  const updatedList = currentList.map(c => c.id === complaint.id ? complaint : c);

  if (channel) {
    try {
      channel.postMessage({ type: 'COMPLAINTS_UPDATED', complaints: updatedList });
    } catch {}
  }

  try {
    fetch('/api/complaints', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ complaint }),
    }).catch(() => {});
  } catch {}

  try {
    const docRef = doc(db, COMPLAINTS_COLLECTION, complaint.id);
    await setDoc(docRef, complaint, { merge: true });
  } catch (err) {
    console.warn('Firestore update complaint error:', err);
  }
}

/**
 * Delete a complaint
 */
export async function deleteComplaint(complaintId: string, currentList: PublicComplaint[]): Promise<void> {
  const updatedList = currentList.filter(c => c.id !== complaintId);

  if (channel) {
    try {
      channel.postMessage({ type: 'COMPLAINTS_UPDATED', complaints: updatedList });
    } catch {}
  }

  try {
    fetch(`/api/complaints/${complaintId}`, { method: 'DELETE' }).catch(() => {});
  } catch {}

  try {
    const docRef = doc(db, COMPLAINTS_COLLECTION, complaintId);
    await deleteDoc(docRef);
  } catch (err) {
    console.warn('Firestore delete complaint error:', err);
  }
}
