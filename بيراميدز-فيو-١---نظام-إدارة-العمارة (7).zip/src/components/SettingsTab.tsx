import React, { useState, useEffect } from 'react';
import { AppConfig, UserRole, AdminResidentProfile } from '../types';
import { 
  Settings, Shield, Plus, Trash2, Check, X, Users, CreditCard, DollarSign, 
  Briefcase, Pencil, BookOpen, Edit3, Calendar, Calculator, CheckCircle2, 
  Moon, Sun, Palette, Sparkles, Home, UserCheck, Phone, BadgeCheck,
  Folder, FolderOpen, HardDrive, ExternalLink, FileSpreadsheet, Database, 
  RefreshCw, Cloud, Image as ImageIcon
} from 'lucide-react';
import * as googleApi from '../services/googleApi';

interface SettingsTabProps {
  config: AppConfig;
  role: UserRole;
  onSaveConfig: (updatedConfig: AppConfig) => void;
  onNotification?: (title: string, message: string, type: 'success' | 'info' | 'warning' | 'error') => void;
  rules?: string[];
  onAddRule?: (ruleText: string) => void;
  onDeleteRule?: (index: number) => void;
  onOpenEditRulesModal?: () => void;
  isDarkMode?: boolean;
  onToggleTheme?: (isDark: boolean) => void;
}

export const SettingsTab: React.FC<SettingsTabProps> = ({
  config,
  role,
  onSaveConfig,
  onNotification,
  rules = [],
  onAddRule,
  onDeleteRule,
  onOpenEditRulesModal,
  isDarkMode = false,
  onToggleTheme,
}) => {
  const isAdmin = role === 'ADMIN';
  const [activeSubTab, setActiveSubTab] = useState<'settings' | 'storage' | 'permissions' | 'types'>('settings');
  const [newRuleInput, setNewRuleInput] = useState('');

  // Automatically reset to settings sub-tab if resident mode
  useEffect(() => {
    if (!isAdmin && activeSubTab === 'storage') {
      setActiveSubTab('settings');
    }
  }, [isAdmin, activeSubTab]);
  
  // Google Drive & Sheets Integration State
  const [driveFolders, setDriveFolders] = useState<googleApi.DriveFoldersMap | null>(() => googleApi.getCachedDriveFolders());
  const [isCheckingFolders, setIsCheckingFolders] = useState(false);
  const [folderSyncMessage, setFolderSyncMessage] = useState<string | null>(null);

  useEffect(() => {
    const cached = googleApi.getCachedDriveFolders();
    if (cached) {
      setDriveFolders(cached);
    }
  }, []);

  const handleSyncDriveFolders = async () => {
    setIsCheckingFolders(true);
    setFolderSyncMessage(null);
    try {
      const updated = await googleApi.ensureDriveFoldersStructure(true);
      setDriveFolders(updated);
      setFolderSyncMessage('تم فحص ومزامنة كافة مجلدات Google Drive وجداول Google Sheets المرتبطة بحساب رئيس الاتحاد بنجاح!');
      setTimeout(() => setFolderSyncMessage(null), 5000);
    } catch (err: any) {
      setFolderSyncMessage('تعذر فحص المجلدات حالياً: ' + (err.message || 'حدث خطأ في الاتصال'));
    } finally {
      setIsCheckingFolders(false);
    }
  };

  // Accounting Settings state
  const defaultFeesMap: Record<string, number> = {
    'سكني': 400,
    'سكني مغلق': 200,
    'مفروش': 600,
    'إداري': 800,
    'تجاري': 500,
    'بدون تشطيب': 0,
  };

  const [accountingStartDate, setAccountingStartDate] = useState(config.accountingStartDate || '2026-01-01');
  const [defaultMonthlyFee, setDefaultMonthlyFee] = useState<number>(config.defaultMonthlyFee || 400);
  const [activityFees, setActivityFees] = useState<Record<string, number>>(() => ({
    ...defaultFeesMap,
    ...(config.activityDefaultFees || {})
  }));
  const [savedSuccess, setSavedSuccess] = useState(false);

  useEffect(() => {
    if (config.accountingStartDate) setAccountingStartDate(config.accountingStartDate);
    if (config.defaultMonthlyFee) setDefaultMonthlyFee(config.defaultMonthlyFee);
    if (config.activityDefaultFees) {
      setActivityFees({ ...defaultFeesMap, ...config.activityDefaultFees });
    }
  }, [config]);

  // Input states for categories
  const [newActivityType, setNewActivityType] = useState('');
  const [newPaymentType, setNewPaymentType] = useState('');
  const [newExpenseType, setNewExpenseType] = useState('');

  const [editingItem, setEditingItem] = useState<{ key: 'activityTypes' | 'paymentTypes' | 'expenseTypes'; originalValue: string } | null>(null);
  const [editValue, setEditValue] = useState('');

  // Editing Modal state for Types
  const [editingModal, setEditingModal] = useState<{
    key: 'activityTypes' | 'paymentTypes' | 'expenseTypes';
    originalValue: string;
    newValue: string;
    fee: number;
    error?: string;
  } | null>(null);

  const openEditModal = (key: 'activityTypes' | 'paymentTypes' | 'expenseTypes', value: string) => {
    const currentFee = activityFees[value] !== undefined ? activityFees[value] : (defaultFeesMap[value] ?? 400);
    setEditingModal({
      key,
      originalValue: value,
      newValue: value,
      fee: currentFee,
      error: undefined,
    });
  };

  const handleConfirmEditModal = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!editingModal) return;
    const trimmedVal = editingModal.newValue.trim();
    if (!trimmedVal) {
      setEditingModal(prev => prev ? { ...prev, error: 'يرجى إدخال اسم النوع' } : null);
      return;
    }

    const key = editingModal.key;
    const isDuplicate = config[key].some(item => item === trimmedVal && item !== editingModal.originalValue);
    if (isDuplicate) {
      setEditingModal(prev => prev ? { ...prev, error: 'هذا الاسم مستخدم بالفعل في القائمة' } : null);
      return;
    }

    const updatedList = config[key].map(item => item === editingModal.originalValue ? trimmedVal : item);
    
    let updatedActivityFees = { ...defaultFeesMap, ...(config.activityDefaultFees || {}), ...activityFees };
    if (key === 'activityTypes') {
      delete updatedActivityFees[editingModal.originalValue];
      updatedActivityFees[trimmedVal] = Number(editingModal.fee) >= 0 ? Number(editingModal.fee) : 0;
      setActivityFees(updatedActivityFees);
    }

    const updated: AppConfig = {
      ...config,
      [key]: updatedList,
      ...(key === 'activityTypes' ? { activityDefaultFees: updatedActivityFees } : {})
    };

    onSaveConfig(updated);
    if (onNotification) {
      const typeLabel = key === 'activityTypes' ? 'نوع الوحدة' : key === 'paymentTypes' ? 'نوع التحصيل' : 'نوع المصروف';
      onNotification('تم تعديل النوع بنجاح', `تم تحديث ${typeLabel} إلى "${trimmedVal}" بنجاح.`, 'success');
    }
    setEditingModal(null);
  };

  // Helper to start inline editing
  const startEditing = (key: 'activityTypes' | 'paymentTypes' | 'expenseTypes', value: string) => {
    setEditingItem({ key, originalValue: value });
    setEditValue(value);
  };

  // Helper to save inline editing
  const handleSaveEdit = (key: 'activityTypes' | 'paymentTypes' | 'expenseTypes') => {
    if (!editingItem || !editValue.trim()) return;
    const trimmedVal = editValue.trim();
    
    const exists = config[key].some(item => item === trimmedVal && item !== editingItem.originalValue);
    if (exists) return;

    const updatedList = config[key].map(item => item === editingItem.originalValue ? trimmedVal : item);
    
    let updatedActivityFees = { ...config.activityDefaultFees, ...activityFees };
    if (key === 'activityTypes') {
      const currentFee = updatedActivityFees[editingItem.originalValue] ?? 0;
      delete updatedActivityFees[editingItem.originalValue];
      updatedActivityFees[trimmedVal] = currentFee;
      setActivityFees(updatedActivityFees);
    }

    const updated = {
      ...config,
      [key]: updatedList,
      ...(key === 'activityTypes' ? { activityDefaultFees: updatedActivityFees } : {})
    };
    onSaveConfig(updated);
    if (onNotification) {
      onNotification('تم تعديل النوع بنجاح', `تم تعديل النوع إلى "${trimmedVal}" بنجاح.`, 'success');
    }
    setEditingItem(null);
    setEditValue('');
  };

  // Input states for admins and assistant
  const [newAdminEmail, setNewAdminEmail] = useState('');
  
  // Technical Assistant state
  const [assistantEmail, setAssistantEmail] = useState(config.assistantConfig?.email || '');
  const [assistantPassword, setAssistantPassword] = useState(config.assistantConfig?.password || '');
  const [assistantName, setAssistantName] = useState(config.assistantConfig?.name || 'المساعد الفني');
  const [assistantSavedSuccess, setAssistantSavedSuccess] = useState(false);

  useEffect(() => {
    if (config.assistantConfig) {
      setAssistantEmail(config.assistantConfig.email || '');
      setAssistantPassword(config.assistantConfig.password || '');
      setAssistantName(config.assistantConfig.name || 'المساعد الفني');
    }
  }, [config.assistantConfig]);

  const handleSaveAssistantConfig = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) return;
    if (!assistantEmail.trim() || !assistantPassword.trim()) return;

    const updated: AppConfig = {
      ...config,
      assistantConfig: {
        email: assistantEmail.trim().toLowerCase(),
        password: assistantPassword.trim(),
        name: assistantName.trim() || 'المساعد الفني',
      },
    };
    onSaveConfig(updated);
    setAssistantSavedSuccess(true);
    setTimeout(() => setAssistantSavedSuccess(false), 3000);
  };

  const handleRemoveAssistantConfig = () => {
    if (!isAdmin) return;
    const updated: AppConfig = {
      ...config,
    };
    delete updated.assistantConfig;
    onSaveConfig(updated);
    setAssistantEmail('');
    setAssistantPassword('');
    setAssistantName('المساعد الفني');
  };

  // Core update helper
  const updateConfig = (key: keyof AppConfig, updatedList: string[]) => {
    if (!isAdmin) return;
    const updated = {
      ...config,
      [key]: updatedList,
    };
    onSaveConfig(updated);
  };

  const handleSaveAccountingSettings = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!isAdmin) return;

    const updated: AppConfig = {
      ...config,
      accountingStartDate: accountingStartDate || '2026-01-01',
      defaultMonthlyFee: defaultMonthlyFee > 0 ? defaultMonthlyFee : 400,
      activityDefaultFees: activityFees,
    };
    onSaveConfig(updated);
    setSavedSuccess(true);
    if (onNotification) {
      onNotification('تم حفظ الإعدادات', 'تم حفظ وتطبيق تاريخ بدء المحاسبة والاشتراكات بنجاح.', 'success');
    }
    setTimeout(() => setSavedSuccess(false), 4000);
  };

  const handleResetDefaultActivityFees = () => {
    setActivityFees(defaultFeesMap);
    setDefaultMonthlyFee(400);
  };

  const handleAddActivityType = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newActivityType.trim();
    if (!trimmed || config.activityTypes.includes(trimmed)) return;
    
    const updatedActivityFees = {
      ...config.activityDefaultFees,
      [trimmed]: 0
    };
    setActivityFees(updatedActivityFees);
    
    const updated = {
      ...config,
      activityTypes: [...config.activityTypes, trimmed],
      activityDefaultFees: updatedActivityFees
    };
    onSaveConfig(updated);
    setNewActivityType('');
  };

  const handleAddPaymentType = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPaymentType.trim() || config.paymentTypes.includes(newPaymentType.trim())) return;
    updateConfig('paymentTypes', [...config.paymentTypes, newPaymentType.trim()]);
    setNewPaymentType('');
  };

  const handleAddExpenseType = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newExpenseType.trim() || config.expenseTypes.includes(newExpenseType.trim())) return;
    updateConfig('expenseTypes', [...config.expenseTypes, newExpenseType.trim()]);
    setNewExpenseType('');
  };

  const handleAddAdmin = (e: React.FormEvent) => {
    e.preventDefault();
    const email = newAdminEmail.trim().toLowerCase();
    if (!email || config.admins.includes(email)) return;
    updateConfig('admins', [...config.admins, email]);
    setNewAdminEmail('');
  };

  const handleDeleteItem = (key: keyof AppConfig, item: string) => {
    if (!isAdmin) return;
    const currentVal = config[key];
    if (!Array.isArray(currentVal)) return;
    const filtered = currentVal.filter((x) => x !== item);
    
    let updatedActivityFees = { ...config.activityDefaultFees };
    if (key === 'activityTypes') {
      delete updatedActivityFees[item];
      setActivityFees(updatedActivityFees);
    }
    
    const updated = {
      ...config,
      [key]: filtered as string[],
      ...(key === 'activityTypes' ? { activityDefaultFees: updatedActivityFees } : {})
    };
    onSaveConfig(updated);
  };

  const handleAddNewRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRuleInput.trim()) return;
    if (onAddRule) {
      onAddRule(newRuleInput.trim());
      setNewRuleInput('');
    }
  };

  // Calculate elapsed months for summary
  const getElapsedMonths = () => {
    try {
      const start = new Date(accountingStartDate || '2026-01-01');
      const now = new Date();
      const months = (now.getFullYear() - start.getFullYear()) * 12 + (now.getMonth() - start.getMonth()) + 1;
      return Math.max(1, months);
    } catch {
      return 1;
    }
  };

  return (
    <div className="w-full space-y-3.5" dir="rtl">
      {/* Header Info */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-100 shadow-xs">
        <div className="text-right">
          <h2 className="text-lg font-black text-slate-900">إعدادات النظام والتحكم</h2>
          <p className="text-xs text-slate-500 mt-0.5 font-bold">تحديد تاريخ بدء المحاسبة وحساب المديونيات، تهيئة المصنفات، وإدارة الصلاحيات واللوائح.</p>
        </div>
      </div>

      {/* 4 Tabs Side-by-Side as explicitly requested */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 bg-slate-100/90 p-1.5 rounded-2xl border border-slate-200/60 shadow-xs w-full">
        <button
          type="button"
          onClick={() => setActiveSubTab('settings')}
          className={`py-2.5 px-3 rounded-xl text-xs sm:text-sm font-black transition flex items-center justify-center gap-2 cursor-pointer ${
            activeSubTab === 'settings' 
              ? 'bg-blue-900 text-white shadow-sm' 
              : 'bg-white/90 text-slate-700 hover:bg-white hover:text-slate-950'
          }`}
        >
          <Calendar className={`w-4 h-4 ${activeSubTab === 'settings' ? 'text-white' : 'text-blue-800'}`} />
          <span>تبويب اعدادات</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('storage')}
          className={`py-2.5 px-3 rounded-xl text-xs sm:text-sm font-black transition flex items-center justify-center gap-2 cursor-pointer ${
            activeSubTab === 'storage' 
              ? 'bg-blue-900 text-white shadow-sm' 
              : 'bg-white/90 text-slate-700 hover:bg-white hover:text-slate-950'
          }`}
        >
          <Cloud className={`w-4 h-4 ${activeSubTab === 'storage' ? 'text-white' : 'text-emerald-700'}`} />
          <span>تبويب سحابة</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('permissions')}
          className={`py-2.5 px-3 rounded-xl text-xs sm:text-sm font-black transition flex items-center justify-center gap-2 cursor-pointer ${
            activeSubTab === 'permissions' 
              ? 'bg-blue-900 text-white shadow-sm' 
              : 'bg-white/90 text-slate-700 hover:bg-white hover:text-slate-950'
          }`}
        >
          <Shield className={`w-4 h-4 ${activeSubTab === 'permissions' ? 'text-white' : 'text-amber-700'}`} />
          <span>تبويب الصلاحيات</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('types')}
          className={`py-2.5 px-3 rounded-xl text-xs sm:text-sm font-black transition flex items-center justify-center gap-2 cursor-pointer ${
            activeSubTab === 'types' 
              ? 'bg-blue-900 text-white shadow-sm' 
              : 'bg-white/90 text-slate-700 hover:bg-white hover:text-slate-950'
          }`}
        >
          <Settings className={`w-4 h-4 ${activeSubTab === 'types' ? 'text-white' : 'text-purple-700'}`} />
          <span>تبويب الأنواع</span>
        </button>
      </div>

      {!isAdmin && (
        <div className="bg-yellow-50/60 border border-yellow-200/60 rounded-xl p-2.5 text-yellow-900 text-xs font-bold text-right leading-relaxed">
          💡 تنبيه: هذه الصفحة مخصصة لعرض القوانين والاختصاصات. وبصفتك ساكنًا، يمكنك الاطلاع عليها لمعرفة حقوقك وواجباتك، بينما ينفرد رئيس اتحاد الملاك بصلاحية التعديل والإضافة.
        </div>
      )}

      {/* SUBTAB 0: GENERAL ACCOUNTING SETTINGS (تاريخ بدء المحاسبة والاشتراكات) */}
      {activeSubTab === 'settings' && (
        <div className="space-y-3.5 text-right">

          {/* Card: Accounting start date and fee defaults */}
          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-100 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b pb-3 gap-2">
              <div className="text-right">
                <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
                  <span className="w-7 h-7 rounded-lg bg-blue-50 text-blue-900 flex items-center justify-center">
                    <Calendar className="w-4 h-4" />
                  </span>
                  <span>تاريخ بدء المحاسبة واحتساب المديونيات والسداد</span>
                </h3>
                <p className="text-xs text-slate-500 font-bold mt-1 leading-relaxed">
                  حدد التاريخ الذي يبدأ منه التطبيق احتساب الشهور المستحقة والمديونيات على الوحدات السكنية ومقارنتها بما تم سداده.
                </p>
              </div>

              {savedSuccess && (
                <div className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-xl text-xs font-black animate-fade-in self-start sm:self-auto">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>تم حفظ وتطبيق الإعدادات بنجاح!</span>
                </div>
              )}
            </div>

            <form onSubmit={handleSaveAccountingSettings} className="space-y-4">
              {/* 1. Start Date Picker and Preset Buttons in One Row */}
              <div className="p-3.5 bg-slate-50/70 border border-slate-200/80 rounded-xl space-y-2.5">
                <label className="block text-xs font-black text-slate-800">
                  تاريخ بدء المحاسبة (سنة - شهر - يوم):
                </label>
                
                {/* 3 Controls on One Single Row */}
                <div className="flex flex-row items-center gap-2 w-full">
                  <input
                    type="date"
                    value={accountingStartDate}
                    onChange={(e) => setAccountingStartDate(e.target.value)}
                    disabled={!isAdmin}
                    className="flex-1 min-w-0 px-3 py-2 bg-white border border-slate-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 rounded-xl text-xs font-black text-slate-800 outline-none transition disabled:bg-slate-100 cursor-pointer text-center"
                    required
                  />

                  {/* Quick Preset Buttons */}
                  {isAdmin && (
                    <>
                      <button
                        type="button"
                        onClick={() => setAccountingStartDate('2026-01-01')}
                        className={`px-2.5 sm:px-3 py-2 text-[10.5px] sm:text-[11px] font-bold rounded-xl transition border cursor-pointer shrink-0 whitespace-nowrap shadow-2xs ${
                          accountingStartDate === '2026-01-01' 
                            ? 'bg-blue-900 text-white border-blue-900' 
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        بداية عام 2026 (2026-01-01)
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          const now = new Date();
                          const y = now.getFullYear();
                          const m = String(now.getMonth() + 1).padStart(2, '0');
                          setAccountingStartDate(`${y}-${m}-01`);
                        }}
                        className={`px-2.5 sm:px-3 py-2 text-[10.5px] sm:text-[11px] font-bold rounded-xl transition border cursor-pointer shrink-0 whitespace-nowrap shadow-2xs ${
                          (() => {
                            const now = new Date();
                            const y = now.getFullYear();
                            const m = String(now.getMonth() + 1).padStart(2, '0');
                            return accountingStartDate === `${y}-${m}-01`;
                          })()
                            ? 'bg-blue-900 text-white border-blue-900'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        أول الشهر الحالي
                      </button>
                    </>
                  )}
                </div>

                <p className="text-[10px] text-slate-400 font-bold leading-relaxed">
                  * تاريخ البدء الحالي المعتمد: <span className="text-blue-900 font-black">{accountingStartDate}</span> (يتم احتساب <span className="text-slate-900 font-black">{getElapsedMonths()}</span> شهر حتى تاريخ اليوم).
                </p>
              </div>

              {/* 3. Default Fees Per Activity Type */}
              <div className="p-4 bg-slate-50/90 border border-slate-200 rounded-2xl space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200/70 pb-2.5">
                  <div>
                    <h4 className="text-xs font-black text-slate-900">
                      قيمة الاشتراك الافتراضي حسب نوع النشاط
                    </h4>
                    <p className="text-[10px] text-slate-500 font-bold mt-0.5">
                      يتم تعيين هذه المبالغ تلقائياً عند إضافة أو تعديل الشقق وفقاً لنوع النشاط المحدد لكل وحدة
                    </p>
                  </div>
                  {isAdmin && (
                    <button
                      type="button"
                      onClick={handleResetDefaultActivityFees}
                      className="px-3 py-1.5 bg-white hover:bg-slate-100 text-blue-900 border border-slate-200 rounded-xl text-[11px] font-bold transition cursor-pointer self-start sm:self-auto"
                    >
                      استعادة القيم الافتراضية المحددة
                    </button>
                  )}
                </div>

                 {/* Grid of Activity Default Fees */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-1">
                  {config.activityTypes.map((act) => {
                    const currentVal = activityFees[act] !== undefined 
                      ? activityFees[act] 
                      : (defaultFeesMap[act] || 0);

                    return (
                      <div
                        key={act}
                        className="bg-white p-3 rounded-xl border border-slate-200/80 space-y-1.5 shadow-2xs"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full bg-blue-900"></span>
                            <span>{act}</span>
                          </span>
                          <span className="text-[10px] font-bold text-slate-400">
                            {act === 'سكني' ? '(الافتراضي 400)' : act === 'سكني مغلق' ? '(الافتراضي 200)' : act === 'مفروش' ? '(الافتراضي 600)' : act === 'إداري' ? '(الافتراضي 800)' : act === 'تجاري' ? '(الافتراضي 500)' : act === 'بدون تشطيب' ? '(الافتراضي 0)' : ''}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <input
                            type="number"
                            min="0"
                            step="10"
                            value={currentVal}
                            onChange={(e) => {
                              const val = parseFloat(e.target.value) || 0;
                              setActivityFees(prev => ({ ...prev, [act]: val }));
                            }}
                            disabled={!isAdmin}
                            className="flex-1 px-2.5 py-1.5 bg-slate-50 focus:bg-white border border-slate-200 focus:border-blue-500 rounded-lg text-xs font-black text-slate-900 outline-none text-right transition disabled:bg-slate-100"
                            placeholder="المبلغ"
                          />
                          <span className="text-[11px] font-bold text-slate-500 shrink-0">ج.م / شهر</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Action Buttons */}
              {isAdmin && (
                <div className="flex flex-col sm:flex-row items-center justify-between pt-3 gap-2 border-t border-slate-100">
                  {savedSuccess ? (
                    <div className="flex items-center gap-2 px-3.5 py-2 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-black animate-fade-in w-full sm:w-auto">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>تم حفظ وتطبيق تاريخ بدء المحاسبة والاشتراكات بنجاح!</span>
                    </div>
                  ) : (
                    <span className="text-[11px] text-slate-400 font-bold hidden sm:inline">
                      يتم حفظ وتطبيق الإعدادات على كشوف الحسابات فور الضغط.
                    </span>
                  )}

                  <button
                    type="submit"
                    className={`w-full sm:w-auto px-5 py-2.5 text-xs font-black rounded-xl shadow-sm hover:shadow transition flex items-center justify-center gap-2 cursor-pointer active:scale-98 ${
                      savedSuccess
                        ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                        : 'bg-blue-900 hover:bg-blue-950 text-white'
                    }`}
                  >
                    {savedSuccess ? (
                      <>
                        <CheckCircle2 className="w-4 h-4" />
                        <span>تم الحفظ بنجاح ✓</span>
                      </>
                    ) : (
                      <>
                        <Check className="w-4 h-4" />
                        <span>حفظ وتطبيق تاريخ بدء المحاسبة والاشتراكات</span>
                      </>
                    )}
                  </button>
                </div>
              )}
            </form>
          </div>

          {/* Educational Calculation Box */}
          <div className="bg-slate-50 p-3.5 sm:p-4 rounded-2xl border border-slate-200/70 space-y-2">
            <h4 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
              <Calculator className="w-4 h-4 text-blue-900" />
              <span>كيف يعمل احتساب رصيد ومديونية كل شقة؟</span>
            </h4>
            <ul className="text-xs text-slate-600 font-bold space-y-1.5 list-disc list-inside leading-relaxed">
              <li>يقوم النظام بعدّ الأشهر المنقضية من <span className="text-blue-900 font-black">تاريخ بدء المحاسبة</span> المحدد أعلاه حتى الشهر الحالي.</li>
              <li>يتم ضرب عدد الأشهر في <span className="text-slate-800 font-black">الرسوم الشهرية</span> المقررة للشقة لمعرفة إجمالي المبالغ المستحقة.</li>
              <li>يقوم النظام بجمع كل المبالغ المسددة في كشف التحصيلات لنفس الوحدة ومقارنتها بإجمالي المستحقات.</li>
              <li>إذا كان هناك عجز في السداد، يظهر الرصيد <span className="text-red-600 font-black">بالسالب وباللون الأحمر</span> (مديونية مستحقة). وإذا سدد الساكن مقدماً، يظهر الرصيد <span className="text-emerald-700 font-black">بالموجب وباللون الأخضر</span>.</li>
            </ul>
          </div>
        </div>
      )}

      {/* SUBTAB: GOOGLE DRIVE & GOOGLE SHEETS STORAGE */}
      {isAdmin && activeSubTab === 'storage' && (
        <div className="space-y-4 text-right">
          {/* Header Card */}
          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-100 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-100 pb-3 gap-3">
              <div className="text-right">
                <div className="flex items-center gap-2">
                  <span className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
                    <Cloud className="w-5 h-5" />
                  </span>
                  <div>
                    <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
                      <span>سحابة التخزين وقواعد البيانات (Google Drive & Google Sheets)</span>
                    </h3>
                    <p className="text-xs text-slate-500 font-bold mt-0.5">
                      النظام مرتبط ومؤمن بحساب Google الرسمي الخاص برئيس الاتحاد وحيد سماحة.
                    </p>
                  </div>
                </div>
              </div>

              {/* Status Badge */}
              <div className="flex items-center gap-2 bg-emerald-50 text-emerald-800 px-3.5 py-1.5 rounded-xl border border-emerald-200/80 text-xs font-black self-start sm:self-auto">
                <BadgeCheck className="w-4 h-4 text-emerald-600" />
                <span>الحساب المرتبط: waheedsamaha8@gmail.com</span>
              </div>
            </div>

            {folderSyncMessage && (
              <div className="p-3 bg-blue-50 text-blue-900 rounded-xl border border-blue-200 text-xs font-black flex items-center gap-2 animate-fade-in">
                <CheckCircle2 className="w-4 h-4 text-blue-700 shrink-0" />
                <span>{folderSyncMessage}</span>
              </div>
            )}

            {/* Main Drive & Sheets Quick Access */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {/* Main Drive Folder Card */}
              <div className="p-4 bg-gradient-to-br from-blue-50/80 to-slate-50 rounded-2xl border border-blue-100 flex flex-col justify-between gap-3">
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="w-7 h-7 rounded-lg bg-blue-600 text-white flex items-center justify-center">
                      <Folder className="w-4 h-4" />
                    </span>
                    <span className="text-[10px] font-black px-2 py-0.5 bg-blue-100 text-blue-800 rounded-full">
                      المجلد الجذري
                    </span>
                  </div>
                  <h4 className="text-xs font-black text-slate-900">مجلد اتحاد الملاك الرئيسي (Google Drive)</h4>
                  <p className="text-[11px] text-slate-500 font-bold leading-relaxed">
                    المجلد الأساسي الذي يضم جدول البيانات المركزي وكافة مجلدات الصور والإيصالات المصنفة تلقائياً.
                  </p>
                </div>

                <a
                  href={driveFolders?.rootFolderUrl || 'https://drive.google.com/'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-2 px-3 bg-blue-900 hover:bg-blue-950 text-white text-xs font-black rounded-xl transition flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>فتح المجلد في Google Drive</span>
                </a>
              </div>

              {/* Main Google Spreadsheet Card */}
              <div className="p-4 bg-gradient-to-br from-emerald-50/80 to-slate-50 rounded-2xl border border-emerald-100 flex flex-col justify-between gap-3">
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center">
                      <FileSpreadsheet className="w-4 h-4" />
                    </span>
                    <span className="text-[10px] font-black px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-full">
                      جدول البيانات
                    </span>
                  </div>
                  <h4 className="text-xs font-black text-slate-900">جدول البيانات المركزي (Google Sheets)</h4>
                  <p className="text-[11px] text-slate-500 font-bold leading-relaxed">
                    ملف شيت الإدارة المركزي "Pyramids View 1 - Management Database" المحفوظ على حساب وحيد سماحة.
                  </p>
                </div>

                <a
                  href={driveFolders?.spreadsheetUrl || 'https://docs.google.com/spreadsheets'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-2 px-3 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-black rounded-xl transition flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>فتح قاعدة البيانات في Google Sheets</span>
                </a>
              </div>
            </div>

            {/* Sync / Check Button */}
            {isAdmin && (
              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  onClick={handleSyncDriveFolders}
                  disabled={isCheckingFolders}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isCheckingFolders ? 'animate-spin' : ''}`} />
                  <span>{isCheckingFolders ? 'جاري فحص وتحديث المجلدات...' : 'إعادة فحص ومزامنة مجلدات جوجل درايف 🔄'}</span>
                </button>
              </div>
            )}
          </div>

          {/* Subfolders Grid Card */}
          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-100 shadow-xs space-y-4">
            <div className="border-b border-slate-100 pb-2.5">
              <h3 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                <FolderOpen className="w-4 h-4 text-blue-900" />
                <span>فولدرات تصنيف وحفظ الصور والبيانات تلقائياً</span>
              </h3>
              <p className="text-[11px] text-slate-500 font-bold mt-1">
                يقوم النظام تلقائياً بتوجيه وتخزين كل صورة أو مستند في الفولدر الخاص به داخل Google Drive فور التقاطها أو رفعها:
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {/* 1. Sheets Folder */}
              <div className="p-3 bg-slate-50 border border-slate-200/80 rounded-xl flex flex-col justify-between gap-2.5">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded bg-emerald-100 text-emerald-800 flex items-center justify-center">
                      <Database className="w-3.5 h-3.5" />
                    </span>
                    <span className="text-xs font-black text-slate-900">قواعد البيانات والجداول</span>
                  </div>
                  <p className="text-[10px] text-slate-500 font-medium">يضم ملف قاعدة بيانات النظام الرئيسي</p>
                </div>
                <a
                  href={driveFolders?.sheetsFolderUrl || driveFolders?.rootFolderUrl || 'https://drive.google.com/'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-2.5 py-1.5 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg text-[11px] font-bold text-slate-800 flex items-center justify-between cursor-pointer"
                >
                  <span>عرض المجلد</span>
                  <ExternalLink className="w-3 h-3 text-slate-400" />
                </a>
              </div>

              {/* 2. Receipts Folder */}
              <div className="p-3 bg-slate-50 border border-slate-200/80 rounded-xl flex flex-col justify-between gap-2.5">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded bg-blue-100 text-blue-800 flex items-center justify-center">
                      <ImageIcon className="w-3.5 h-3.5" />
                    </span>
                    <span className="text-xs font-black text-slate-900">صور إيصالات السداد</span>
                  </div>
                  <p className="text-[10px] text-slate-500 font-medium">تخزين صور إيصالات التحصيل وسندات القبض</p>
                </div>
                <a
                  href={driveFolders?.receiptsFolderUrl || driveFolders?.rootFolderUrl || 'https://drive.google.com/'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-2.5 py-1.5 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg text-[11px] font-bold text-slate-800 flex items-center justify-between cursor-pointer"
                >
                  <span>عرض المجلد</span>
                  <ExternalLink className="w-3 h-3 text-slate-400" />
                </a>
              </div>

              {/* 3. Expenses Folder */}
              <div className="p-3 bg-slate-50 border border-slate-200/80 rounded-xl flex flex-col justify-between gap-2.5">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded bg-amber-100 text-amber-800 flex items-center justify-center">
                      <CreditCard className="w-3.5 h-3.5" />
                    </span>
                    <span className="text-xs font-black text-slate-900">صور فواتير المصروفات</span>
                  </div>
                  <p className="text-[10px] text-slate-500 font-medium">فواتير الكهرباء والمياه وقطع الغيار والصيانة</p>
                </div>
                <a
                  href={driveFolders?.expensesFolderUrl || driveFolders?.rootFolderUrl || 'https://drive.google.com/'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-2.5 py-1.5 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg text-[11px] font-bold text-slate-800 flex items-center justify-between cursor-pointer"
                >
                  <span>عرض المجلد</span>
                  <ExternalLink className="w-3 h-3 text-slate-400" />
                </a>
              </div>

              {/* 4. Complaints Folder */}
              <div className="p-3 bg-slate-50 border border-slate-200/80 rounded-xl flex flex-col justify-between gap-2.5">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded bg-rose-100 text-rose-800 flex items-center justify-center">
                      <Shield className="w-3.5 h-3.5" />
                    </span>
                    <span className="text-xs font-black text-slate-900">صور الشكاوى والصيانة</span>
                  </div>
                  <p className="text-[10px] text-slate-500 font-medium">صور بلاغات الأعطال وشكاوى السكان المرفوعة</p>
                </div>
                <a
                  href={driveFolders?.complaintsFolderUrl || driveFolders?.rootFolderUrl || 'https://drive.google.com/'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-2.5 py-1.5 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg text-[11px] font-bold text-slate-800 flex items-center justify-between cursor-pointer"
                >
                  <span>عرض المجلد</span>
                  <ExternalLink className="w-3 h-3 text-slate-400" />
                </a>
              </div>

              {/* 5. Chat Attachments Folder */}
              <div className="p-3 bg-slate-50 border border-slate-200/80 rounded-xl flex flex-col justify-between gap-2.5">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded bg-purple-100 text-purple-800 flex items-center justify-center">
                      <Folder className="w-3.5 h-3.5" />
                    </span>
                    <span className="text-xs font-black text-slate-900">صور ومرفقات المحادثات</span>
                  </div>
                  <p className="text-[10px] text-slate-500 font-medium">المرفقات والصور المتبادلة في غرفة المحادثة</p>
                </div>
                <a
                  href={driveFolders?.chatFolderUrl || driveFolders?.rootFolderUrl || 'https://drive.google.com/'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-2.5 py-1.5 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg text-[11px] font-bold text-slate-800 flex items-center justify-between cursor-pointer"
                >
                  <span>عرض المجلد</span>
                  <ExternalLink className="w-3 h-3 text-slate-400" />
                </a>
              </div>
            </div>
          </div>

          {/* Info & Security Guarantee */}
          <div className="p-4 bg-emerald-50/70 border border-emerald-200/80 rounded-2xl text-xs text-emerald-950 font-bold space-y-1.5 leading-relaxed">
            <div className="flex items-center gap-2 text-emerald-900 font-black">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>ضمان استمرارية وأمان البيانات</span>
            </div>
            <p>
              يتم حفظ ومزامنة كافة السجلات في جدول Google Sheets السحابي المرتبط بحساب رئيس الاتحاد (waheedsamaha8@gmail.com). هذا يضمن حفظ كافة البيانات في حسابك بشكل مستقل ودائم، مع إمكانية الوصول للملفات وتصديرها أو مشاركتها في أي وقت من هاتفك أو حاسوبك عبر تطبيقات Google الرسمية.
            </p>
          </div>
        </div>
      )}

      {/* SUBTAB 1: MANAGING TYPES AND CATEGORIES */}
      {activeSubTab === 'types' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 text-right">
          {/* 1. Apartment Types */}
          <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-100 shadow-xs flex flex-col space-y-3">
            <div className="flex items-center justify-between border-b pb-2">
              <span className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
                <Users className="w-3.5 h-3.5" />
              </span>
              <h3 className="text-xs font-black text-slate-900">إدارة أنواع الوحدات</h3>
            </div>
            
            <p className="text-[10px] text-slate-400 font-semibold leading-relaxed">تعريف الأنشطة المخصصة للشقق والمنشآت وتصنيفها.</p>

            {isAdmin && (
              <form onSubmit={handleAddActivityType} className="flex gap-1">
                <button
                  type="submit"
                  className="px-2.5 bg-blue-900 text-white rounded-lg font-bold text-xs hover:bg-blue-950 transition flex items-center justify-center cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
                <input
                  type="text"
                  placeholder="نوع جديد (مثال: عيادة)"
                  value={newActivityType}
                  onChange={(e) => setNewActivityType(e.target.value)}
                  className="flex-1 px-2.5 py-1.5 bg-slate-50 border border-slate-100 focus:bg-white rounded-lg text-xs outline-none text-right font-bold transition"
                  required
                />
              </form>
            )}

            <div className="space-y-1.5">
              {config.activityTypes.map((type) => {
                const fee = activityFees[type] !== undefined ? activityFees[type] : (defaultFeesMap[type] ?? 400);
                return (
                  <div key={type} className="flex items-center justify-between p-2 bg-slate-50/70 hover:bg-slate-100/70 border border-slate-200/80 rounded-xl transition gap-2">
                    {isAdmin ? (
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleDeleteItem('activityTypes', type)}
                          className="p-1.5 text-red-500 hover:bg-red-50 hover:text-red-700 rounded-lg transition cursor-pointer"
                          title="حذف هذا النوع"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => openEditModal('activityTypes', type)}
                          className="p-1.5 text-blue-700 hover:bg-blue-100/70 hover:text-blue-900 rounded-lg transition cursor-pointer flex items-center gap-1 text-[11px] font-bold bg-blue-50/80 px-2"
                          title="تعديل هذا النوع والاشتراك"
                        >
                          <Pencil className="w-3 h-3 text-blue-800" />
                          <span>تعديل</span>
                        </button>
                      </div>
                    ) : (
                      <span className="w-4" />
                    )}

                    <div className="flex items-center gap-1.5 truncate">
                      <span className="text-[11px] font-bold text-slate-500 bg-white px-2 py-0.5 rounded-md border border-slate-200 shrink-0">
                        {fee} ج.م
                      </span>
                      <span className="text-xs font-black text-indigo-950 truncate">{type}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 2. Payment Types */}
          <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-100 shadow-xs flex flex-col space-y-3">
            <div className="flex items-center justify-between border-b pb-2">
              <span className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
                <CreditCard className="w-3.5 h-3.5" />
              </span>
              <h3 className="text-xs font-black text-slate-900">إدارة أنواع التحصيلات</h3>
            </div>

            <p className="text-[10px] text-slate-400 font-semibold leading-relaxed">تحديد فئات الإيرادات والاشتراكات المقررة على سكان العمارة بانتظام.</p>

            {isAdmin && (
              <form onSubmit={handleAddPaymentType} className="flex gap-1">
                <button
                  type="submit"
                  className="px-2.5 bg-blue-900 text-white rounded-lg font-bold text-xs hover:bg-blue-950 transition flex items-center justify-center cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
                <input
                  type="text"
                  placeholder="نوع تحصيل (مثال: صيانة غاز)"
                  value={newPaymentType}
                  onChange={(e) => setNewPaymentType(e.target.value)}
                  className="flex-1 px-2.5 py-1.5 bg-slate-50 border border-slate-100 focus:bg-white rounded-lg text-xs outline-none text-right font-bold transition"
                  required
                />
              </form>
            )}

            <div className="space-y-1.5">
              {config.paymentTypes.map((type) => {
                return (
                  <div key={type} className="flex items-center justify-between p-2 bg-slate-50/70 hover:bg-slate-100/70 border border-slate-200/80 rounded-xl transition gap-2">
                    {isAdmin ? (
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleDeleteItem('paymentTypes', type)}
                          className="p-1.5 text-red-500 hover:bg-red-50 hover:text-red-700 rounded-lg transition cursor-pointer"
                          title="حذف هذا النوع"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => openEditModal('paymentTypes', type)}
                          className="p-1.5 text-emerald-800 hover:bg-emerald-100/70 rounded-lg transition cursor-pointer flex items-center gap-1 text-[11px] font-bold bg-emerald-50/80 px-2"
                          title="تعديل هذا النوع"
                        >
                          <Pencil className="w-3 h-3 text-emerald-800" />
                          <span>تعديل</span>
                        </button>
                      </div>
                    ) : (
                      <span className="w-4" />
                    )}
                    <span className="text-xs font-black text-emerald-950 truncate">{type}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 3. Expense Types */}
          <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-100 shadow-xs flex flex-col space-y-3">
            <div className="flex items-center justify-between border-b pb-2">
              <span className="w-7 h-7 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
                <DollarSign className="w-3.5 h-3.5" />
              </span>
              <h3 className="text-xs font-black text-slate-900">إدارة أنواع المصروفات</h3>
            </div>

            <p className="text-[10px] text-slate-400 font-semibold leading-relaxed">تعريف بنود الصرف وأوجه النفقات المسموح بها من قبل اتحاد الملاك.</p>

            {isAdmin && (
              <form onSubmit={handleAddExpenseType} className="flex gap-1">
                <button
                  type="submit"
                  className="px-2.5 bg-blue-900 text-white rounded-lg font-bold text-xs hover:bg-blue-950 transition flex items-center justify-center cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
                <input
                  type="text"
                  placeholder="بند مصروف (مثال: صيانة جراج)"
                  value={newExpenseType}
                  onChange={(e) => setNewExpenseType(e.target.value)}
                  className="flex-1 px-2.5 py-1.5 bg-slate-50 border border-slate-100 focus:bg-white rounded-lg text-xs outline-none text-right font-bold transition"
                  required
                />
              </form>
            )}

            <div className="space-y-1.5">
              {config.expenseTypes.map((type) => {
                return (
                  <div key={type} className="flex items-center justify-between p-2 bg-slate-50/70 hover:bg-slate-100/70 border border-slate-200/80 rounded-xl transition gap-2">
                    {isAdmin ? (
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleDeleteItem('expenseTypes', type)}
                          className="p-1.5 text-red-500 hover:bg-red-50 hover:text-red-700 rounded-lg transition cursor-pointer"
                          title="حذف هذا النوع"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => openEditModal('expenseTypes', type)}
                          className="p-1.5 text-amber-900 hover:bg-amber-100/70 rounded-lg transition cursor-pointer flex items-center gap-1 text-[11px] font-bold bg-amber-50/80 px-2"
                          title="تعديل هذا النوع"
                        >
                          <Pencil className="w-3 h-3 text-amber-800" />
                          <span>تعديل</span>
                        </button>
                      </div>
                    ) : (
                      <span className="w-4" />
                    )}
                    <span className="text-xs font-black text-amber-950 truncate">{type}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 2: RESPONSIBILITIES AND PERMISSIONS */}
      {activeSubTab === 'permissions' && (
        <div className="space-y-3 text-right">
          {/* Rules Management Card inside Permissions */}
          <div className="bg-white p-3 sm:p-4 rounded-2xl border border-slate-100 shadow-xs space-y-3 text-right">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b pb-2.5 gap-2">
              <div className="text-right">
                <h3 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                  <BookOpen className="w-4 h-4 text-yellow-700" />
                  <span>تعديل وصياغة لائحة وتعليمات إدارة العمارة ({rules.length})</span>
                </h3>
                <p className="text-[10px] text-slate-400 font-bold mt-0.5">
                  يمكن لرئيس الاتحاد إضافة وتعديل وحذف بنود وقواعد حسن الجوار المنظمة للعقار ليطلع عليها جميع السكان.
                </p>
              </div>
              {onOpenEditRulesModal && isAdmin && (
                <button
                  onClick={onOpenEditRulesModal}
                  className="px-3 py-1.5 bg-blue-50 text-blue-900 hover:bg-blue-100 rounded-xl text-xs font-bold transition flex items-center gap-1.5 self-start cursor-pointer"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>فتح نافذة التعديل المنفصلة</span>
                </button>
              )}
            </div>

            {isAdmin && (
              <form onSubmit={handleAddNewRule} className="flex gap-1.5">
                <button
                  type="submit"
                  className="px-3.5 py-2 bg-blue-900 text-white rounded-xl font-bold text-xs hover:bg-blue-950 active:scale-[0.98] transition flex items-center gap-1 cursor-pointer shrink-0"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>إضافة مادة للائحة</span>
                </button>
                <input
                  type="text"
                  placeholder="اكتب نص المادة أو التعليمات الجديدة (مثال: يمنع استخدام المصعد لنقل مواد البناء الثقيلة)..."
                  value={newRuleInput}
                  onChange={(e) => setNewRuleInput(e.target.value)}
                  className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 focus:bg-white focus:border-blue-500 rounded-xl text-xs outline-none text-right font-bold transition"
                  required
                />
              </form>
            )}

            {/* List of rules */}
            <div className="space-y-2">
              {rules.length === 0 ? (
                <p className="text-center text-xs text-slate-400 font-bold py-4">لا توجد مواد تعليمات مسجلة حالياً.</p>
              ) : (
                rules.map((rule, idx) => (
                  <div key={idx} className="flex items-start justify-between gap-2.5 p-2.5 bg-slate-50/60 hover:bg-slate-50 border border-slate-100 rounded-xl transition">
                    {isAdmin && onDeleteRule && (
                      <button
                        onClick={() => onDeleteRule(idx)}
                        className="p-1 text-red-500 hover:bg-red-50 rounded-lg transition cursor-pointer shrink-0"
                        title="حذف البند"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <div className="flex-1 text-right">
                      <span className="inline-block px-1.5 py-0.5 bg-yellow-50 text-yellow-900 border border-yellow-200/50 text-[10px] font-black rounded-md ml-2">
                        مادة {idx + 1}
                      </span>
                      <span className="text-xs text-slate-800 font-bold leading-relaxed">{rule}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Split roles comparison grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            
            {/* 1. Admin/President Capabilities */}
            <div className="bg-white p-3.5 sm:p-4.5 rounded-2xl border border-slate-100 shadow-xs space-y-3">
              <div className="flex items-center justify-between border-b pb-2 mb-1">
                <span className="px-2.5 py-0.5 bg-blue-900 text-white text-[10px] font-black rounded-md">رئيس الاتحاد (المدير الإداري)</span>
                <h3 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                  <span>صلاحيات رئيس الاتحاد</span>
                  <Shield className="w-3.5 h-3.5 text-blue-950 fill-blue-50" />
                </h3>
              </div>

              <p className="text-xs text-slate-500 font-bold leading-relaxed">يتمتع رئيس الاتحاد بكامل الصلاحيات الإدارية والرقابية والمالية لضمان سلامة تشغيل العقار ومصالح الملاك العليا.</p>

              <div className="space-y-2">
                {[
                  'إدارة وإضافة وحذف وحساب شؤون السكان',
                  'تسجيل، تعديل، وحذف كشوفات التحصيلات والاشتراكات المعتمدة',
                  'تسجيل وتحديث وفلترة وحذف فواتير المصروفات والنفقات',
                  'صياغة وإدارة اللائحة الداخلية وجدول العقوبات للعمارة',
                  'صياغة ونشر القرارات والاستبيانات التفاعلية وتصفية الأصوات',
                  'تنسيق وإقرار الأجندة والأحداث في تقويم العمارة التفاعلي',
                  'إرسال التنبيهات والإشعارات العامة لكافة السكان دفعة واحدة',
                  'تعديل وإعادة تهيئة إعدادات النظام ومصنفات الوحدات والتحصيلات',
                ].map((cap, idx) => (
                  <div key={idx} className="flex items-start gap-2">
                    <span className="mt-0.5 w-3.5 h-3.5 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                    </span>
                    <span className="text-xs text-slate-700 font-bold leading-normal">{cap}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* 2. Resident Capabilities */}
            <div className="bg-white p-3.5 sm:p-4.5 rounded-2xl border border-slate-100 shadow-xs space-y-3">
              <div className="flex items-center justify-between border-b pb-2 mb-1">
                <span className="px-2.5 py-0.5 bg-amber-50 text-amber-700 text-[10px] font-black rounded-md">ساكن / مالك وحدة</span>
                <h3 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                  <span>صلاحيات الساكن والشفافية المتاحة</span>
                  <Briefcase className="w-3.5 h-3.5 text-amber-600" />
                </h3>
              </div>

              <p className="text-xs text-slate-500 font-bold leading-relaxed">يستمتع الساكن بنظام كامل من الشفافية لتبادل الآراء والمشاركة المجتمعية مع حماية الخصوصية الشخصية.</p>

              <div className="space-y-2 border-b pb-3 mb-2">
                {/* Granted permissions */}
                {[
                  'الاطلاع الشامل على كشوف المبالغ المحصلة والتحققات المالية (للقراءة فقط)',
                  'الاطلاع التفصيلي على فواتير ومستندات المصروفات (للقراءة فقط)',
                  'المشاركة والتصويت الفعال في استبيانات القرارات العامة والجمعية العمومية',
                  'كتابة ونشر الشكاوى والتعليقات والتحذيرات على لوحة النقاشات المفتوحة',
                  'المحادثة والتفاعل الفوري مع الجيران في صفحة الدردشة الفورية',
                  'الاطلاع على لوائح وتعليمات العمارة للقراءة فقط',
                  'تقديم ومتابعة طلبات الصيانة الخاصة بالوحدة وتلقي الإشعار فور إصلاحها',
                ].map((cap, idx) => (
                  <div key={idx} className="flex items-start gap-2">
                    <span className="mt-0.5 w-3.5 h-3.5 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                    </span>
                    <span className="text-xs text-slate-700 font-bold leading-normal">{cap}</span>
                  </div>
                ))}
              </div>

              {/* Explicit Restrictions */}
              <div className="space-y-1.5">
                <h4 className="text-[11px] font-extrabold text-red-600 mb-1">🚫 يمنع تماماً على الساكن:</h4>
                {[
                  'إضافة أو حذف أو تعديل بيانات وحسابات شقق الجيران الآخرين',
                  'إضافة أو تعديل أو إلغاء قيود التحصيل أو إيصالات الدفع الرسمية',
                  'تسجيل أو تعديل أو إلغاء فواتير ومصروفات العقار الموحدة',
                  'تعديل أو حذف أو تلاعب بلوائح وتعليمات اتحاد الملاك الأساسية',
                ].map((cap, idx) => (
                  <div key={idx} className="flex items-start gap-2">
                    <span className="mt-0.5 w-3.5 h-3.5 rounded-full bg-red-50 text-red-500 flex items-center justify-center shrink-0">
                      <X className="w-2.5 h-2.5 stroke-[3]" />
                    </span>
                    <span className="text-xs text-slate-500 font-semibold leading-normal">{cap}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Executive users configuration (admins and managers list) */}
          {isAdmin && (
            <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-100 shadow-xs grid grid-cols-1 md:grid-cols-2 gap-3">
              
              {/* Admins Emails config */}
              <div className="space-y-2.5">
                <h4 className="text-xs font-black text-slate-800 border-b pb-1.5">تفويض بريد إلكتروني لرئاسة الاتحاد (الأدمن)</h4>
                <p className="text-[10px] text-slate-400 font-semibold leading-relaxed">أدخل بريد جوجل الإلكتروني الخاص برئيس اتحاد الملاك لمنحه كل الصلاحيات.</p>
                
                <form onSubmit={handleAddAdmin} className="flex gap-1.5">
                  <button
                    type="submit"
                    className="px-3 py-1.5 bg-blue-900 text-white text-xs font-bold rounded-lg hover:bg-blue-950 transition cursor-pointer"
                  >
                    تفعيل تفويض أدمن
                  </button>
                  <input
                    type="email"
                    placeholder="email@gmail.com"
                    value={newAdminEmail}
                    onChange={(e) => setNewAdminEmail(e.target.value)}
                    className="flex-1 px-2.5 py-1.5 bg-slate-50 border border-slate-100 focus:bg-white rounded-lg text-xs outline-none text-left font-bold transition"
                    required
                  />
                </form>

                <div className="space-y-1 max-h-32 overflow-y-auto">
                  {config.admins.map((email) => (
                    <div key={email} className="flex items-center justify-between p-1.5 bg-slate-50 rounded-lg border border-slate-100">
                      <button
                        onClick={() => handleDeleteItem('admins', email)}
                        className="p-1 text-red-500 hover:bg-red-50 rounded-md transition cursor-pointer"
                        title="إلغاء التفويض"
                        disabled={email === 'waheedsamaha8@gmail.com'} // Protect main user
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                      <span className="text-[10px] font-bold text-slate-700">{email}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Technical Assistant Config */}
              <div className="space-y-2.5 bg-slate-50 dark:bg-slate-800/40 p-3 rounded-xl border border-slate-200/80 dark:border-slate-700 col-span-1 md:col-span-1">
                <div className="flex items-center justify-between border-b border-slate-200/80 dark:border-slate-700 pb-2">
                  <div>
                    <h4 className="text-xs font-black text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                      <UserCheck className="w-4 h-4 text-blue-600" />
                      <span>تفويض مساعد فني</span>
                    </h4>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 font-semibold leading-relaxed mt-0.5">
                      تحديد إيميل وباسورد المساعد الفني لتسجيل التحصيل والمصروفات ومتابعة الصيانة والدليل والتقويم دون صلاحيات التعديل أو الحذف.
                    </p>
                  </div>
                  {config.assistantConfig?.email && (
                    <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-black rounded-md border border-emerald-200 shrink-0">
                      تفويض مفعل
                    </span>
                  )}
                </div>

                <form onSubmit={handleSaveAssistantConfig} className="space-y-2.5 pt-1">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] font-bold text-slate-600 dark:text-slate-300 block mb-1">البريد الإلكتروني (Email)</label>
                      <input
                        type="email"
                        placeholder="assistant@pyramids.com"
                        value={assistantEmail}
                        onChange={(e) => setAssistantEmail(e.target.value)}
                        className="w-full px-2.5 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-bold outline-none text-left"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-slate-600 dark:text-slate-300 block mb-1">كلمة المرور (Password)</label>
                      <input
                        type="text"
                        placeholder="كلمة المرور"
                        value={assistantPassword}
                        onChange={(e) => setAssistantPassword(e.target.value)}
                        className="w-full px-2.5 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-bold outline-none text-left"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-slate-600 dark:text-slate-300 block mb-1">اسم المساعد الفني (اختياري)</label>
                    <input
                      type="text"
                      placeholder="مثال: المساعد الفني"
                      value={assistantName}
                      onChange={(e) => setAssistantName(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-bold outline-none text-right"
                    />
                  </div>

                  <div className="flex items-center justify-between pt-1 gap-2">
                    {config.assistantConfig?.email ? (
                      <button
                        type="button"
                        onClick={handleRemoveAssistantConfig}
                        className="px-2.5 py-1.5 bg-red-50 hover:bg-red-100 text-red-600 text-xs font-bold rounded-lg transition cursor-pointer flex items-center gap-1 shrink-0"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>إلغاء التفويض</span>
                      </button>
                    ) : <div />}

                    <button
                      type="submit"
                      className="px-3.5 py-1.5 bg-blue-900 hover:bg-blue-950 text-white text-xs font-black rounded-lg transition cursor-pointer flex items-center gap-1 shadow-2xs shrink-0"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>حفظ تفويض المساعد</span>
                    </button>
                  </div>

                  {assistantSavedSuccess && (
                    <div className="bg-emerald-50 text-emerald-800 text-[10px] font-bold p-2 rounded-lg border border-emerald-200 text-center">
                      تم تفعيل وحفظ تفويض المساعد الفني بنجاح!
                    </div>
                  )}
                </form>
              </div>

            </div>
          )}
        </div>
      )}

      {/* Modal: Edit Type Dialog */}
      {editingModal && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in" dir="rtl">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl border border-slate-100 space-y-4">
            <div className="flex items-center justify-between border-b pb-3">
              <div className="flex items-center gap-2">
                <span className="w-8 h-8 rounded-xl bg-blue-50 text-blue-900 flex items-center justify-center">
                  <Pencil className="w-4 h-4" />
                </span>
                <div>
                  <h3 className="text-sm font-black text-slate-900">
                    {editingModal.key === 'activityTypes' ? 'تعديل نوع الوحدة' : editingModal.key === 'paymentTypes' ? 'تعديل نوع التحصيل' : 'تعديل نوع المصروف'}
                  </h3>
                  <p className="text-[11px] text-slate-500 font-bold">
                    الاسم الحالي: <span className="text-slate-800 font-black">{editingModal.originalValue}</span>
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEditingModal(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleConfirmEditModal} className="space-y-3.5">
              <div className="space-y-1.5">
                <label className="block text-xs font-black text-slate-800">
                  الاسم الجديد:
                </label>
                <input
                  type="text"
                  value={editingModal.newValue}
                  onChange={(e) => setEditingModal(prev => prev ? { ...prev, newValue: e.target.value, error: undefined } : null)}
                  className="w-full px-3 py-2 bg-slate-50 focus:bg-white border border-slate-200 focus:border-blue-500 rounded-xl text-xs font-black text-slate-900 outline-none text-right transition"
                  placeholder="أدخل الاسم الجديد"
                  autoFocus
                  required
                />
              </div>

              {editingModal.key === 'activityTypes' && (
                <div className="space-y-1.5">
                  <label className="block text-xs font-black text-slate-800">
                    الاشتراك الشهري الافتراضي لهذا النشاط:
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min="0"
                      step="10"
                      value={editingModal.fee}
                      onChange={(e) => setEditingModal(prev => prev ? { ...prev, fee: Number(e.target.value) || 0 } : null)}
                      className="flex-1 px-3 py-2 bg-slate-50 focus:bg-white border border-slate-200 focus:border-blue-500 rounded-xl text-xs font-black text-slate-900 outline-none text-right transition"
                    />
                    <span className="text-xs font-bold text-slate-500 shrink-0">ج.م / شهر</span>
                  </div>
                </div>
              )}

              {editingModal.error && (
                <p className="text-xs text-red-600 font-bold bg-red-50 p-2.5 rounded-xl border border-red-100">
                  {editingModal.error}
                </p>
              )}

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditingModal(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-black rounded-xl transition cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-900 hover:bg-blue-950 text-white text-xs font-black rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>حفظ التعديل</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

